import {
  Application,
  Assets,
  Container,
  Graphics,
  Sprite,
  Texture,
} from 'pixi.js'

import {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react'

import {
  centerCamera,
  clampZoom,
  fitCamera,
  panCamera,
  type MapCamera,
  zoomCameraAtPoint,
} from '../lib/mapCamera'

import type {
  GridSettings,
  SceneMapAsset,
} from '../types/scene'

export interface MapViewportHandle {
  fitMap: () => void
  actualSize: () => void
  zoomIn: () => void
  zoomOut: () => void
}

interface MapViewportProps {
  activeMap: SceneMapAsset | null
  grid: GridSettings
  panEnabled: boolean
  onCameraChange?: (camera: MapCamera) => void
}

interface MapSize {
  width: number
  height: number
}

const INITIAL_CAMERA: MapCamera = {
  x: 0,
  y: 0,
  zoom: 1,
}

function normalizedOffset(value: number, cellSize: number): number {
  return ((value % cellSize) + cellSize) % cellSize
}

export const MapViewport = forwardRef<MapViewportHandle, MapViewportProps>(
  function MapViewport(
    {
      activeMap,
      grid,
      panEnabled,
      onCameraChange,
    },
    ref,
  ) {
    const hostRef = useRef<HTMLDivElement>(null)
    const appRef = useRef<Application | null>(null)
    const worldRef = useRef<Container | null>(null)
    const gridRef = useRef<Graphics | null>(null)
    const mapSizeRef = useRef<MapSize>({ width: 0, height: 0 })
    const cameraRef = useRef<MapCamera>({ ...INITIAL_CAMERA })
    const panEnabledRef = useRef(panEnabled)
    const pointerRef = useRef({
      active: false,
      pointerId: null as number | null,
      lastX: 0,
      lastY: 0,
    })
    const [ready, setReady] = useState(false)

    useEffect(() => {
      panEnabledRef.current = panEnabled
    }, [panEnabled])

    const applyCamera = (camera: MapCamera) => {
      cameraRef.current = camera

      const world = worldRef.current
      if (world) {
        world.position.set(camera.x, camera.y)
        world.scale.set(camera.zoom)
      }

      onCameraChange?.(camera)
    }

    const viewportSize = () => {
      const app = appRef.current
      return app
        ? { width: app.screen.width, height: app.screen.height }
        : { width: 0, height: 0 }
    }

    const fitMap = () => {
      const size = mapSizeRef.current
      if (size.width <= 0 || size.height <= 0) return
      applyCamera(fitCamera(viewportSize(), size, 34))
    }

    const actualSize = () => {
      const size = mapSizeRef.current
      if (size.width <= 0 || size.height <= 0) return
      applyCamera(centerCamera(viewportSize(), size, 1))
    }

    const zoomBy = (factor: number) => {
      const viewport = viewportSize()
      if (viewport.width <= 0 || viewport.height <= 0) return

      const current = cameraRef.current
      applyCamera(
        zoomCameraAtPoint(
          current,
          {
            x: viewport.width / 2,
            y: viewport.height / 2,
          },
          current.zoom * factor,
        ),
      )
    }

    useImperativeHandle(ref, () => ({
      fitMap,
      actualSize,
      zoomIn: () => zoomBy(1.2),
      zoomOut: () => zoomBy(1 / 1.2),
    }))

    useEffect(() => {
      const host = hostRef.current
      if (!host) return

      let cancelled = false
      const app = new Application()

      const start = async () => {
        await app.init({
          resizeTo: host,
          antialias: true,
          autoDensity: true,
          resolution: Math.min(window.devicePixelRatio || 1, 2),
          background: '#050403',
          backgroundAlpha: 1,
        })

        if (cancelled) {
          app.destroy(true)
          return
        }

        app.canvas.className = 'pixi-map-canvas'
        app.canvas.setAttribute('aria-label', 'Battle map viewport')
        host.appendChild(app.canvas)

        const world = new Container()
        world.sortableChildren = true
        app.stage.addChild(world)

        appRef.current = app
        worldRef.current = world
        setReady(true)
      }

      start()

      return () => {
        cancelled = true
        setReady(false)
        gridRef.current = null
        worldRef.current = null
        appRef.current = null
        app.destroy(true)
      }
    }, [])

    useEffect(() => {
      if (!ready) return

      const world = worldRef.current
      if (!world) return

      let cancelled = false

      const load = async () => {
        const oldChildren = world.removeChildren()
        for (const child of oldChildren) child.destroy()

        gridRef.current = null
        mapSizeRef.current = { width: 0, height: 0 }

        if (!activeMap) {
          applyCamera({ ...INITIAL_CAMERA })
          return
        }

        const texture = await Assets.load<Texture>(activeMap.url)
        if (cancelled) return

        const mapSprite = new Sprite(texture)
        mapSprite.position.set(0, 0)
        mapSprite.zIndex = 0

        const gridGraphics = new Graphics()
        gridGraphics.zIndex = 10

        world.addChild(mapSprite)
        world.addChild(gridGraphics)

        gridRef.current = gridGraphics
        mapSizeRef.current = {
          width: texture.width,
          height: texture.height,
        }

        requestAnimationFrame(() => fitMap())
      }

      load()

      return () => {
        cancelled = true
      }
    }, [ready, activeMap?.id, activeMap?.url])

    useEffect(() => {
      const graphics = gridRef.current
      const size = mapSizeRef.current

      if (!graphics || size.width <= 0 || size.height <= 0) return

      graphics.clear()
      if (!grid.enabled) return

      const cellSize = Math.max(10, grid.cellSize)
      const startX = normalizedOffset(grid.offsetX, cellSize)
      const startY = normalizedOffset(grid.offsetY, cellSize)
      const maxLines = 5000
      let lineCount = 0

      for (
        let x = startX;
        x <= size.width && lineCount < maxLines;
        x += cellSize
      ) {
        graphics.moveTo(x, 0).lineTo(x, size.height)
        lineCount += 1
      }

      for (
        let y = startY;
        y <= size.height && lineCount < maxLines;
        y += cellSize
      ) {
        graphics.moveTo(0, y).lineTo(size.width, y)
        lineCount += 1
      }

      graphics.stroke({
        width: 1.25,
        color: 0xe5d7ad,
        alpha: grid.opacity,
      })
    }, [
      ready,
      activeMap?.id,
      grid.enabled,
      grid.cellSize,
      grid.offsetX,
      grid.offsetY,
      grid.opacity,
    ])

    useEffect(() => {
      if (!ready) return
      const app = appRef.current
      if (!app) return

      const canvas = app.canvas

      const onWheel = (event: WheelEvent) => {
        if (!activeMap) return
        event.preventDefault()

        const rect = canvas.getBoundingClientRect()
        const point = {
          x: event.clientX - rect.left,
          y: event.clientY - rect.top,
        }
        const current = cameraRef.current
        const factor = Math.exp(-event.deltaY * 0.0014)

        applyCamera(
          zoomCameraAtPoint(
            current,
            point,
            clampZoom(current.zoom * factor),
          ),
        )
      }

      const onPointerDown = (event: PointerEvent) => {
        const shouldPan =
          (panEnabledRef.current && event.button === 0) ||
          event.button === 1

        if (!activeMap || !shouldPan) return

        event.preventDefault()
        pointerRef.current = {
          active: true,
          pointerId: event.pointerId,
          lastX: event.clientX,
          lastY: event.clientY,
        }

        canvas.setPointerCapture(event.pointerId)
        canvas.classList.add('is-dragging')
      }

      const onPointerMove = (event: PointerEvent) => {
        const pointer = pointerRef.current
        if (!pointer.active || pointer.pointerId !== event.pointerId) return

        const deltaX = event.clientX - pointer.lastX
        const deltaY = event.clientY - pointer.lastY
        pointer.lastX = event.clientX
        pointer.lastY = event.clientY

        applyCamera(panCamera(cameraRef.current, deltaX, deltaY))
      }

      const endPointer = (event: PointerEvent) => {
        const pointer = pointerRef.current
        if (pointer.pointerId !== event.pointerId) return

        pointer.active = false
        pointer.pointerId = null
        canvas.classList.remove('is-dragging')

        if (canvas.hasPointerCapture(event.pointerId)) {
          canvas.releasePointerCapture(event.pointerId)
        }
      }

      const onDoubleClick = () => fitMap()

      canvas.addEventListener('wheel', onWheel, { passive: false })
      canvas.addEventListener('pointerdown', onPointerDown)
      canvas.addEventListener('pointermove', onPointerMove)
      canvas.addEventListener('pointerup', endPointer)
      canvas.addEventListener('pointercancel', endPointer)
      canvas.addEventListener('dblclick', onDoubleClick)

      return () => {
        canvas.removeEventListener('wheel', onWheel)
        canvas.removeEventListener('pointerdown', onPointerDown)
        canvas.removeEventListener('pointermove', onPointerMove)
        canvas.removeEventListener('pointerup', endPointer)
        canvas.removeEventListener('pointercancel', endPointer)
        canvas.removeEventListener('dblclick', onDoubleClick)
      }
    }, [ready, activeMap?.id])

    useEffect(() => {
      const host = hostRef.current
      if (!host || !ready) return

      let previousWidth = host.clientWidth
      let previousHeight = host.clientHeight

      const observer = new ResizeObserver(() => {
        const nextWidth = host.clientWidth
        const nextHeight = host.clientHeight
        const camera = cameraRef.current

        if (
          previousWidth <= 0 ||
          previousHeight <= 0 ||
          camera.zoom <= 0
        ) {
          previousWidth = nextWidth
          previousHeight = nextHeight
          return
        }

        const worldCenterX = (previousWidth / 2 - camera.x) / camera.zoom
        const worldCenterY = (previousHeight / 2 - camera.y) / camera.zoom

        previousWidth = nextWidth
        previousHeight = nextHeight

        applyCamera({
          x: nextWidth / 2 - worldCenterX * camera.zoom,
          y: nextHeight / 2 - worldCenterY * camera.zoom,
          zoom: camera.zoom,
        })
      })

      observer.observe(host)
      return () => observer.disconnect()
    }, [ready])

    return (
      <div
        ref={hostRef}
        className={[
          'pixi-map-host',
          panEnabled ? 'is-pan-mode' : '',
          activeMap ? 'has-map' : 'is-empty',
        ].join(' ')}
      >
        {!activeMap ? (
          <div className="pixi-empty-map">
            <div className="pixi-empty-map-mark">◇</div>
            <strong>No map revealed</strong>
            <span>The active battle map will appear here.</span>
          </div>
        ) : null}
      </div>
    )
  },
)
