D&D WEB VTT — Visual Pass v3

This is a visual-only replacement. No database, server, map, grid, socket, or campaign logic changes.

Fixes:
- Zoom percentage no longer uses Pieces of Eight, so the broken "%" / flag-like glyph disappears.
- "Dice will decide your fate." is substantially larger.
- Campaign title is larger.
- Battle-map frame is now multi-layer wood + brass with ornamental corners.
- Header, toolbar, inspector, tabs, and bottom dock have a stronger old-fantasy / D&D tabletop visual hierarchy.
- Grid editor remains width-safe.
- Mobile keeps compact controls.

Files:
- src/App.css
- public/assets/ui/frame-corner.svg
- public/assets/ui/ornament-banner.svg
- public/assets/ui/panel-divider.svg

Apply:
1) Ctrl+C
2) Extract over F:\DND WEB VTT
3) npm.cmd run build
4) npm.cmd run server
5) Open http://localhost:3000
